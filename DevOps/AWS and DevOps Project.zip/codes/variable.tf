variable "key_name" {
  description = "Name of the key pair to access EC2 instances"
  type        = string
  default     = "keypairohio" # 🔁 Replace with your actual key pair name
}
