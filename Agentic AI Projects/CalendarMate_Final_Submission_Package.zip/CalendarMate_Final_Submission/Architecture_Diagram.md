# CalendarMate — Architecture Diagram

This file is the GitHub-compatible entry point for the CalendarMate architecture documentation.

The detailed architecture, Mermaid diagram, component responsibilities, orchestration rationale, data flow, tool rationale, observability, security, and implementation boundary are maintained in:

**[`docs/architecture.md`](docs/architecture.md)**

The rendered architecture image is:

**[`docs/architecture-diagram.png`](docs/architecture-diagram.png)**

## Architecture Decision

**Router / Dispatcher** — implemented using three route-filter components feeding the Scheduler, Email, and Follow-Up specialist agents.

> **Accuracy note:** The exported JSON contains Google Calendar Read/Write and Gmail Read components, but the connected validated execution path uses Mock Calendar and Mock Gmail tools. The submission therefore distinguishes prototype validation from live production integration.
