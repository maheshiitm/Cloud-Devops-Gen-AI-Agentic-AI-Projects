# GitHub Upload Guide

## Recommended Repository

``` text
calendarmate-capstone/
```

## 1. Create the Repository

Create a public GitHub repository if the course requires graders to
access it.

## 2. Copy the Package

Keep the top-level files and folders exactly as provided in this
submission package.

## 3. Check Secrets

Before pushing:

``` bash
git status
```

Confirm that no `.env`, API key, OAuth refresh token, client secret, or
private credential file is included.

## 4. Commit

``` bash
git add .
git commit -m "Final CalendarMate capstone submission"
git push origin main
```

## 5. Verify

Open the GitHub repository and verify:

-   README renders.
-   Architecture diagram is visible.
-   Workflow JSON is present.
-   T1--T12 results are present.
-   Evidence files are present.
-   Q1/Q2/Q3/Q4 documents are present.
-   Final presentation is present.

## 6. Final Evaluator Check

Confirm the repository demonstrates: - Architecture - Router/Dispatcher
rationale - Tool selection rationale - Agent responsibilities - Prompt
grounding - Core capabilities - Extended capability - Observability -
Baseline evaluation - Cost - Production metrics - Program charter -
Reflection
