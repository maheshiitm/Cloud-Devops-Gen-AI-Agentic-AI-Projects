# Briefing Agent - System Prompt & Implementation Guide

**Agent Name:** CalendarMate Briefing Agent  
**Role:** Daily Schedule & Email Summary with Conflict Detection  
**Orchestration:** Router pattern → Briefing Agent → Response Formatter  
**Tools:** Google Calendar API (v3), Gmail API (v1)  
**Testing Status:** Baseline tests T1, T2, T10, T12  

---

## System Prompt (Copy-Paste Ready)

```
ROLE:
You are the CalendarMate Briefing Agent. Your single responsibility is to 
provide a comprehensive daily briefing by securely reading and summarizing 
the user's schedule and their unread or important emails.

You do NOT create, modify, delete, or schedule calendar events. You do NOT 
send, reply to, or delete emails. You are a read-only summarization engine.

INPUT:
You will receive a user request routed to you by the Orchestrator Agent. 
Common requests include:
  - "Give me my briefing for today"
  - "What's on my calendar tomorrow?"
  - "Do I have any conflicts this week?"
  - "What's happening on [specific date]?"

OUTPUT:
Return a clearly formatted briefing containing exactly these sections:

1. SCHEDULE SUMMARY
   - List every calendar event for the requested period
   - For each event include:
     * Event Title
     * Start time and End time (in HH:MM format)
     * Attendees (names or emails)
     * Google Meet link (if present)
     * Duration
   
2. SCHEDULING CONFLICTS
   - Explicitly list any overlapping events
   - If NO conflicts exist, state: "No scheduling conflicts detected"
   - For each conflict show: which events overlap and by how many minutes
   
3. EMAIL TRIAGE
   - List recent or important emails (max last 24 hours)
   - For each email show:
     * Sender name/email
     * Subject line
     * 1-2 sentence summary of content
     * Action required? (Yes/No/Maybe)
   - Group by urgency: HIGH, MEDIUM, LOW
   - Separate ACTION ITEMS from FYI ONLY emails

4. DAILY FOCUS PLAN
   - Provide a brief 1-2 sentence synthesis of the day's priorities
   - Based on the meetings and emails reviewed
   - Suggest the most important meeting or task to prioritize

RULES:
1. You MUST use the Calendar Read tool to fetch schedule data.
2. You MUST use the Gmail Read tool to fetch email data.
3. You do NOT create, modify, or delete calendar events.
4. You do NOT send, reply to, or delete emails.
5. You do NOT invent, guess, or hallucinate meetings, attendees, or email content.
6. If a calendar is completely empty for the requested period, explicitly state:
   "You have no meetings scheduled for this period."
7. If there are no emails, explicitly state:
   "You have no new emails requiring attention."
8. All times must be clearly formatted (e.g., "9:00 AM - 10:30 AM").
9. If the user requests a specific date, only return data for that date.
10. If the user requests "this week", return data for Mon-Fri of the current week.

HALLUCINATION PREVENTION:
- Do NOT fabricate any calendar events
- Do NOT invent attendee names or email addresses
- Do NOT make up email content or senders
- Do NOT assume meetings that weren't in the API response
- Do NOT assume email tone or intent if not clearly stated

VAGUE INPUT RULE (CRITICAL):
If the user's request is too vague to determine the specific date or 
timeframe for the briefing, respond with:

"I need clarification to give you the right briefing. Did you mean:
- Today (current date)?
- Tomorrow?
- A specific date? (please provide)
- This week (Mon-Fri)?
- This month?"

Do NOT assume or invent a timeframe. Do NOT default to today if unclear.
Instead, ask the user to be specific.

EDGE CASES:
- User asks for "next Monday" → confirm which Monday (1 week from now?)
- User asks for "last week" → ask if they mean the previous week
- User asks for "sometime next week" → ask for a specific day
- User asks for "ASAP" meeting → ask what dates work best
```

---

## Implementation in Langflow

### 1. Node Configuration

**Node Type:** Agent  
**Model:** GPT-4o-mini (or Claude 3.5 Sonnet)  
**Temperature:** 0.3 (low creativity, focused responses)  
**Max Tokens:** 2000

**System Prompt Field:**
Paste the entire prompt above into the `system_prompt` field.

### 2. Input Configuration

| Input Field | Type | Description |
|-------------|------|-------------|
| `input_value` | String | User's briefing request |
| `tools` | Array | [Calendar Read Tool, Gmail Read Tool] |

### 3. Tool Setup

#### Tool 1: Calendar Read Tool
```
Tool Name: calendar_read_today

Type: HTTP Request

Endpoint: GET /calendar/v3/calendars/primary/events

Parameters:
  - timeMin: (ISO 8601 format, start of requested day)
  - timeMax: (ISO 8601 format, end of requested day)
  - orderBy: startTime
  - singleEvents: true
  - maxResults: 50

Response Parse:
  Extract from response.items:
    - summary (title)
    - start.dateTime (start time)
    - end.dateTime (end time)
    - attendees[] (names/emails)
    - hangoutLink (Google Meet)
```

#### Tool 2: Gmail Read Tool
```
Tool Name: gmail_read_unread

Type: HTTP Request

Endpoint: GET /gmail/v1/users/me/messages

Parameters:
  - q: is:unread newer_than:1d (last 24 hours)
  - maxResults: 20

Response Parse:
  For each message:
    - Get message ID
    - Fetch full message: GET /gmail/v1/users/me/messages/{id}
    - Extract:
      * From (sender)
      * Subject
      * Body (text/plain)
      * Labels (importance)
```

### 4. Output Configuration

**Output Field:** `response`  
**Type:** Message  
**Format:** Natural language text (as specified in OUTPUT section)

---

## Testing Methodology

### Test 1: Happy Path - Today's Briefing

**Input:** "Give me my briefing for today"

**Expected Output Should Contain:**
- ✅ "SCHEDULE SUMMARY" section
- ✅ List of actual calendar events with times
- ✅ Attendee names (not invented)
- ✅ Google Meet links (if present in calendar)
- ✅ "SCHEDULING CONFLICTS" section (either "No conflicts" or list conflicts)
- ✅ "EMAIL TRIAGE" section
- ✅ Emails grouped by HIGH/MEDIUM/LOW
- ✅ "DAILY FOCUS PLAN" section with actionable priorities

**Pass Criteria:**
- Output matches actual calendar data (no fabrication)
- All sections present in correct format
- Times are accurate and clearly formatted

### Test 2: Empty Calendar - No Fabrication

**Setup:** Test on a day you know is completely empty

**Input:** "What do I have on [empty date]?"

**Expected Output Must Include:**
- ✅ Explicitly state: "You have no meetings scheduled for this period."
- ✅ NO invented meetings or events
- ✅ Focus on emails and priorities instead
- ✅ NOT: "You have a free day" (that's fine too)

**Pass Criteria:**
- Zero fabricated events
- Clear acknowledgment of empty calendar
- Graceful handling without assumptions

### Test 3: Conflict Detection

**Setup:** Create two overlapping calendar events

**Input:** "Do I have any conflicts this week?"

**Expected Output Must Include:**
- ✅ "SCHEDULING CONFLICTS" section with explicit conflicts listed
- ✅ Show which events overlap
- ✅ Show overlap duration
- ✅ Example: "Meeting A (2-3 PM) overlaps with Meeting B (2:30-3:30 PM)"

**Pass Criteria:**
- Correctly identifies all overlaps
- Clear explanation of conflict details
- Not missing any conflicts

### Test 4: Vague Input Handling

**Input:** "Give me a briefing" (no date specified)

**Expected Output:**
- ✅ Response asks for clarification
- ✅ Offers specific options (Today? Tomorrow? This week?)
- ✅ Does NOT assume or default to today
- ✅ Does NOT provide a briefing without clarity

**Pass Criteria:**
- Follows Vague Input Rule
- Asks user to clarify before proceeding
- Does not make assumptions

### Test 5: Email Triage Accuracy

**Input:** "Summarize my unread emails"

**Expected Output Should Have:**
- ✅ Actual email senders (no invented)
- ✅ Actual email subjects (not summarized incorrectly)
- ✅ Brief summaries of content
- ✅ HIGH/MEDIUM/LOW priority grouping
- ✅ Separate "ACTION ITEMS" from "FYI ONLY"
- ✅ No fabricated emails

**Pass Criteria:**
- All emails are real (verify against Gmail inbox)
- No invented senders or subjects
- Accurate priority assessment
- Action items correctly identified

---

## Isolated Testing Protocol

### Step 1: Set Up Isolated Environment

1. In Langflow canvas, **disconnect** the Orchestrator Agent from Briefing Agent
2. Add a **Chat Input node** directly to the canvas
3. Connect Chat Input → Briefing Agent (input_value handle)
4. Connect Briefing Agent (response output) → **Chat Output node**
5. Leave other agents (Scheduler, Email, Follow-Up) disconnected

**Verification:**
- Only Briefing Agent node shows execution (blue highlight)
- No other agents execute

### Step 2: Run Happy Path Test

**Command:**
```
"Give me my briefing for today"
```

**Watch For:**
1. Briefing Agent makes API call to Calendar (should see in Langfuse)
2. Briefing Agent makes API call to Gmail (should see in Langfuse)
3. Output contains SCHEDULE SUMMARY section
4. Output contains EMAIL TRIAGE section
5. No errors in Langfuse trace

**Success Criteria:**
- ✅ Two API calls executed (Calendar + Gmail)
- ✅ Output includes both schedule and emails
- ✅ Format matches specification
- ✅ No fabrications

### Step 3: Run Hallucination Test

**Setup:**
- Find a date on your calendar that is completely empty
- Verify by checking your Google Calendar directly

**Command:**
```
"What do I have on [empty date]?"
```

**Watch For:**
1. Agent should call Calendar API
2. Response should acknowledge empty calendar
3. NO invented meetings or events
4. Clear statement: "You have no meetings scheduled"

**Success Criteria:**
- ✅ Correctly reports empty calendar
- ✅ Zero fabricated events
- ✅ Handles gracefully without hallucinating

### Step 4: Review Langfuse Trace

1. Open Langfuse dashboard
2. Find the most recent trace
3. Expand the trace to see:
   - **Input:** The exact user request
   - **Tool Calls:** Calendar API call, Gmail API call
   - **API Response:** Raw JSON from Google APIs
   - **Output:** Final formatted response from Briefing Agent

**Verification Points:**
- Input is what you typed ✓
- Tool calls are correct ✓
- API response contains real data ✓
- Output correctly transforms data ✓
- No hallucinated data in output ✓

---

## Common Issues & Fixes

### Issue: Agent Invents Meetings

**Symptom:** Output includes meetings that don't exist in calendar

**Fix:**
1. Check system prompt - ensure "HALLUCINATION PREVENTION" section is present
2. Lower temperature to 0.2 (less creative)
3. Check if Calendar API is actually being called (verify in Langfuse)
4. Add explicit instruction: "If the API returns no events, state 'no meetings'"

### Issue: Agent Doesn't Call Calendar API

**Symptom:** Output is generic text, no API response in Langfuse trace

**Fix:**
1. Verify Calendar Read Tool is properly wired to Briefing Agent's `tools` handle
2. Check tool endpoint URL is correct
3. Verify OAuth credentials are set in global variables
4. Test tool in isolation first (Langflow "Test Tools" feature)

### Issue: Vague Input Rule Not Followed

**Symptom:** Agent assumes a timeframe when user doesn't specify

**Fix:**
1. Copy-paste exact VAGUE INPUT RULE section into system prompt
2. Add example in prompt: "If user says 'briefing', do NOT assume 'today'"
3. Test with actual vague input: "Give me a briefing"
4. Verify output asks for clarification

### Issue: Email Fabrication

**Symptom:** Agent includes emails that don't exist

**Fix:**
1. Ensure Gmail Read Tool is actually being called
2. Check tool is correctly parsing Gmail API response
3. Lower temperature to 0.2
4. Add to prompt: "Only report emails that appear in Gmail API response"

---

## Success Metrics

| Metric | Target | How to Measure |
|--------|--------|-----------------|
| **T1 Baseline Test Pass** | 100% | Schedule matches actual calendar |
| **T2 Tomorrow's Meetings** | 100% | Correctly lists tomorrow, no fabrication |
| **T10 Weekly Conflicts** | 100% | Detects all overlapping events |
| **T12 Specific Date** | 100% | Returns only requested date's events |
| **Hallucination Rate** | 0% | No invented meetings in 10 test runs |
| **Latency** | <2 sec | Langfuse average duration |
| **Token Usage** | ~500 | Per request (calendar read) |

---

## Integration Checklist

Before connecting to Orchestrator:

- [ ] System prompt fully copied into agent node
- [ ] Calendar Read Tool connected to `tools` handle
- [ ] Gmail Read Tool connected to `tools` handle
- [ ] Chat Input configured for testing
- [ ] Chat Output configured for testing
- [ ] Temperature set to 0.3 or lower
- [ ] All 5 tests passing (T1, T2, T10, T12, hallucination test)
- [ ] Langfuse traces reviewed for correctness
- [ ] No API errors in trace logs
- [ ] Output format matches specification

---

## Next Agent: Scheduler Agent

Once Briefing Agent is working perfectly, connect it back to the Router and build the **Scheduler Agent**. The Scheduler Agent is more complex because it requires:

1. **Availability checking** (reading calendar)
2. **User confirmation** (two-phase commit)
3. **Event creation** (modifying calendar)
4. **Google Meet link generation**

See `SCHEDULER_AGENT_PROMPT.md` for the Scheduler Agent system prompt and testing methodology.

---

*CalendarMate Briefing Agent | Mahesh P. Zade | 09 Sept 2026*
