# Scheduler Agent - System Prompt & Implementation Guide

**Agent Name:** CalendarMate Scheduler Agent  
**Role:** Availability Checking & Event Creation with Guardrails  
**Orchestration:** Router pattern → Scheduler Agent → Response Formatter  
**Tools:** Google Calendar API (v3), Google Meet API  
**Testing Status:** Baseline tests T3, T4, T5, T6, T9, T11  
**Complexity Level:** HIGH (Two-phase commit, availability logic)

---

## System Prompt (Copy-Paste Ready)

```
ROLE:
You are the CalendarMate Scheduler Agent. Your single responsibility is to 
intelligently handle meeting scheduling requests by checking real-time 
availability, proposing open time slots, and creating calendar events with 
Google Meet links.

You MUST check availability before creating any calendar event. You MUST 
ask for clarification when information is ambiguous. You MUST NOT create 
events without user confirmation.

INPUT:
You will receive scheduling requests routed by the Orchestrator Agent. 
Common requests include:
  - "Schedule a 30-minute meeting with sarah@company.com tomorrow at 2pm"
  - "Find a time for a 1-hour meeting with john and lisa next Monday"
  - "Set up a sync with the design team sometime this week"
  - "Schedule something for Sunday at 6am"

OUTPUT (Two-Phase Process):

PHASE 1 - VALIDATION & CLARIFICATION
If any of the following information is missing or ambiguous, respond with 
what you need before proceeding:
  - Meeting duration (default: 30 min if not specified)
  - Date or timeframe (MUST be explicit, no assumptions)
  - Time or time range (must be clear, not vague)
  - Attendees (MUST have at least one external attendee email)
  - Meeting title/purpose (optional but helpful)

Response format for missing info:
"I'd be happy to schedule this meeting. I need clarification on:
- [List what's missing]
- [Offer options if appropriate]
Once you clarify, I'll check availability and propose times."

PHASE 2 - AVAILABILITY CHECK & PROPOSAL
Once you have all required information:
  1. Check YOUR calendar for conflicts (Calendar API)
  2. Check EACH attendee's calendar for conflicts (Calendar API with delegation)
  3. Propose 3 DIFFERENT time slots that work for everyone
  4. For each slot, show:
     * Date and time (e.g., "Monday, Sept 9, 2-3 PM")
     * Who's available
     * Any notes (back-to-back with other meetings, etc.)

Response format:
"I found availability for a [duration] meeting with [attendees]. Here are 
my top 3 options:

Option 1: [Date/Time] 
  ✓ You available | ✓ [Attendee 1] available | ✓ [Attendee 2] available

Option 2: [Date/Time]
  ✓ You available | ✓ [Attendee 1] available | ✓ [Attendee 2] available

Option 3: [Date/Time]
  ✓ You available | ✓ [Attendee 1] available | ✓ [Attendee 2] available

Which option works best for you? Reply with the option number or a different 
time if these don't work."

PHASE 3 - EVENT CREATION (Requires User Confirmation)
Once user confirms a time slot, create the calendar event with:
  - Event title (meeting name or default: "Meeting with [attendees]")
  - Start time (user's confirmed time)
  - Duration (specified duration)
  - Attendees (all provided attendees + user)
  - Google Meet link (auto-generated)
  - Description (optional context from user)

Confirmation response:
"✓ Meeting confirmed!

📅 [Meeting Title]
🕐 [Date] [Time] - [End Time]
👥 Attendees: [List]
🎥 Google Meet: [Link]

Calendar invitations have been sent to all attendees."

RULES:
1. You MUST use Calendar API to check availability BEFORE creating any event.
2. You MUST propose at least 3 different time slots (not just one).
3. You MUST get explicit user confirmation BEFORE creating the event.
4. You MUST NOT create events with missing attendees.
5. You MUST NOT assume a timeframe if the user is vague.
6. You MUST NOT book 6am on a Sunday without explicit confirmation.
7. You MUST NOT ignore time zone differences (if applicable).
8. You MUST NOT create duplicate meetings (check if meeting already exists).
9. You MUST automatically generate Google Meet links for all meetings.
10. You MUST include all attendees in the calendar invite.

GUARDRAIL: MISSING INFORMATION
If required information is missing or ambiguous:
  - Do NOT call Calendar APIs
  - Do NOT create any calendar events
  - Instead, respond with exactly what you need
  - Offer clarifying questions to the user
  - Wait for explicit answer before proceeding

GUARDRAIL: UNUSUAL TIMES
If the user requests an unusual time (6am, 11pm, Sunday, etc.):
  - Flag it explicitly: "That's a weekend/unusual hour"
  - Ask for confirmation: "Did you really mean [date] at [time]?"
  - Wait for explicit confirmation before creating
  - Do NOT assume they meant something else

GUARDRAIL: CONFLICT DETECTION
If there are conflicts in any attendee's calendar:
  - List the conflicting event(s)
  - Suggest alternative times that avoid conflicts
  - Ask user if they want to reschedule the conflicting meeting
  - Do NOT create a double-booking

HALLUCINATION PREVENTION:
  - Do NOT fabricate attendee availability
  - Do NOT invent open time slots
  - Do NOT assume attendee responses
  - Do NOT create meetings without data from Calendar API
  - Do NOT guess at time zones or availability

VAGUE INPUT RULE:
If the request is too vague, ask for clarification:

"I'd be happy to help schedule this meeting. Could you clarify:
- Who should be invited? (email addresses)
- What day or timeframe works? (specific date or range)
- What time do you prefer? (specific time or range)
- How long should it be? (duration in minutes)"

Do NOT assume any of these details. Wait for explicit answers.
```

---

## Implementation in Langflow

### 1. Node Configuration

**Node Type:** Agent  
**Model:** GPT-4o-mini or Claude 3.5 Sonnet  
**Temperature:** 0.2 (low creativity for strict logic)  
**Max Tokens:** 2500 (needs more for multi-option responses)

**System Prompt Field:**
Paste the entire prompt above.

### 2. Input Configuration

| Input Field | Type | Description |
|-------------|------|-------------|
| `input_value` | String | User's scheduling request |
| `tools` | Array | [Calendar Read, Calendar Create, Meet Link Generator] |

### 3. Tool Setup

#### Tool 1: Calendar Check Availability
```
Tool Name: calendar_check_availability

Type: HTTP Request

Endpoint: GET /calendar/v3/calendars/primary/events

Parameters:
  - timeMin: (ISO start of search range)
  - timeMax: (ISO end of search range)
  - q: (search for existing meetings)
  - maxResults: 50

Usage Example:
  Check if 2-3 PM tomorrow is free by querying all events for tomorrow
  If result contains events in that time, mark as unavailable
```

#### Tool 2: Check Attendee Availability
```
Tool Name: calendar_check_attendee_availability

Type: HTTP Request

Endpoint: POST /calendar/v3/calendars/primary/freeBusy

Body: 
{
  "timeMin": "2024-09-10T00:00:00Z",
  "timeMax": "2024-09-10T23:59:59Z",
  "items": [
    {"id": "attendee1@company.com"},
    {"id": "attendee2@company.com"}
  ]
}

Response Parse:
  Extract calendars[].busy[] to see occupied times
  Identify free windows: when busy[] has gaps
```

#### Tool 3: Create Calendar Event
```
Tool Name: calendar_create_event

Type: HTTP Request

Endpoint: POST /calendar/v3/calendars/primary/events

Body:
{
  "summary": "Meeting with [attendees]",
  "description": "[user-provided description]",
  "start": {
    "dateTime": "2024-09-10T14:00:00",
    "timeZone": "America/New_York"
  },
  "end": {
    "dateTime": "2024-09-10T15:00:00",
    "timeZone": "America/New_York"
  },
  "attendees": [
    {"email": "user@company.com", "responseStatus": "accepted"},
    {"email": "attendee1@company.com"},
    {"email": "attendee2@company.com"}
  ],
  "conferenceData": {
    "createRequest": {
      "requestId": "[UUID]",
      "conferenceSolutionKey": {"type": "hangoutsMeet"}
    }
  }
}

Usage:
  Only call AFTER user confirms a time slot
  Automatically generates Google Meet link
  Sends invites to all attendees
```

### 4. Output Configuration

**Output Field:** `response`  
**Type:** Message  
**Format:** Two-phase response (clarification or proposal)

---

## Testing Methodology

### Test 1: Complete Information - Happy Path

**Input:** "Schedule a 30-minute meeting with sarah@company.com tomorrow at 2pm"

**Expected Output:**
- ✅ Check availability for tomorrow 2-2:30 PM
- ✅ Propose 3 time slots (or confirm 2pm if available)
- ✅ Show attendee availability
- ✅ Ask for user confirmation

**Pass Criteria:**
- Availability is checked (see in Langfuse trace)
- 3 options proposed (or user option confirmed)
- Waits for confirmation before creating

### Test 2: Ambiguous Input - Asks Clarification

**Input:** "Set up a sync with the design team sometime this week"

**Expected Output Must Include:**
- ✅ Response asking: "Who exactly should be invited?"
- ✅ Response asking: "What time works best?"
- ✅ Response asking: "How long should it be?"
- ✅ Does NOT create event without clarification

**Pass Criteria:**
- Follows Vague Input Rule exactly
- Asks for all missing information
- Does NOT make assumptions
- Does NOT create calendar event

### Test 3: Multi-Attendee Scheduling

**Input:** "Find a time for a 1-hour meeting with john@ext.com and lisa@ext.com next Monday"

**Expected Output Should:**
- ✅ Check availability for john AND lisa (both calendars)
- ✅ Find times that work for EVERYONE
- ✅ Propose 3 options that show all attendees available
- ✅ Include john and lisa in attendee list

**Pass Criteria:**
- Checks both attendees' calendars
- Proposes times that work for all
- Explicitly shows each person available for each slot

### Test 4: Edge Case - Weekend/Unusual Hour

**Input:** "Schedule something for Sunday at 6am"

**Expected Output Must Include:**
- ✅ Flag: "That's a weekend and an unusual hour"
- ✅ Ask: "Did you really mean Sunday at 6am?"
- ✅ Wait for confirmation
- ✅ Do NOT create without explicit "yes"

**Pass Criteria:**
- Detects unusual time
- Asks for confirmation
- Does not proceed without explicit approval

### Test 5: Missing Attendee Info

**Input:** "Book a meeting but I forgot with whom"

**Expected Output:**
- ✅ Asks: "Who should be invited? (please provide email)"
- ✅ Does NOT create calendar event
- ✅ Waits for attendee email address

**Pass Criteria:**
- Catches missing attendees
- Does not create empty meeting
- Asks for specific attendee info

### Test 6: Conflict Detection

**Input:** "Schedule a meeting at the same time as my existing standup"

**Expected Output Should:**
- ✅ Detect conflict: "Conflicts with your existing Standup at [time]"
- ✅ Propose alternative times
- ✅ Ask if user wants to reschedule standup
- ✅ Do NOT create conflicting event

**Pass Criteria:**
- Finds actual conflict in calendar
- Warns user explicitly
- Offers alternatives
- Respects existing commitments

---

## Isolated Testing Protocol

### Step 1: Set Up Isolated Testing

1. **Disconnect** from Orchestrator (if connected)
2. Add **Chat Input node**
3. Connect Chat Input → Scheduler Agent (input_value)
4. Connect Scheduler Agent (response) → **Chat Output node**
5. Verify only Scheduler Agent executes

### Step 2: Test Happy Path First

**Run:** "Schedule a 30-minute meeting with me@company.com at 2pm tomorrow"

**Watch For:**
1. Langfuse shows Calendar API call
2. Agent proposes specific time
3. Asks for confirmation (does NOT create yet)

### Step 3: Test Clarification Flow

**Run:** "Setup meeting this week"

**Watch For:**
1. Agent asks about attendees
2. Agent asks about time preference
3. Agent asks about duration
4. NO calendar event created
5. Agent waits for clarification

### Step 4: Test Conflict Detection

**Setup:**
- Create a test calendar event (e.g., "Standup" on Tuesday 10-11 AM)

**Run:** "Schedule 1 hour with alice@company.com Tuesday at 10:30am"

**Watch For:**
1. Calendar API shows conflict
2. Agent warns: "Conflicts with Standup"
3. Suggests alternatives
4. Does NOT create conflicting event

### Step 5: Review Langfuse Traces

For each test, check Langfuse:
- ✅ Input matches what you typed
- ✅ Calendar API called with correct parameters
- ✅ Response contains availability data
- ✅ Output matches expected format
- ✅ No events created until user confirms

---

## Common Issues & Fixes

### Issue: Agent Creates Event Without Confirmation

**Symptom:** Event appears in calendar after agent response

**Fix:**
1. Add explicit line to prompt: "Do NOT create event until user confirms"
2. Add to output format: "Which option works? Reply with number"
3. Implement two-message flow: (1) propose, (2) await confirmation
4. Lower temperature to 0.2

### Issue: Agent Doesn't Check Attendee Availability

**Symptom:** Event created but attendee was busy

**Fix:**
1. Verify "Check Attendee Availability" tool is connected
2. Check tool endpoint is correct (freeBusy API)
3. Verify attendee emails are being passed to tool
4. Add to prompt: "You MUST check each attendee's calendar"

### Issue: Unusual Time Not Flagged

**Symptom:** 6am Sunday meeting created without warning

**Fix:**
1. Add explicit check to prompt for unusual times
2. Add examples: "6am, 11pm, Sundays, Saturdays"
3. Require explicit confirmation for edge cases
4. Implement validation logic before event creation

### Issue: Ambiguous Input Not Caught

**Symptom:** Agent assumes time zone or date

**Fix:**
1. Copy VAGUE INPUT RULE section exactly
2. Add examples of ambiguous inputs
3. Test with "sometime this week"
4. Verify Langfuse shows clarification response (not event creation)

---

## Success Metrics

| Metric | Target | How to Measure |
|--------|--------|-----------------|
| **T3 Single Attendee** | 100% | Creates event, includes Meet link |
| **T4 Ambiguous Input** | 100% | Asks clarification, no event created |
| **T5 Multi-Attendee** | 100% | Checks all attendees' availability |
| **T6 Unusual Time** | 100% | Flags and asks confirmation |
| **T9 Missing Info** | 100% | Asks for attendee, no event created |
| **T11 Conflict Detection** | 100% | Detects conflict, suggests alternatives |
| **Confirmation Required** | 100% | Event only created after explicit "yes" |
| **Meet Link Generation** | 100% | All created events have Google Meet link |
| **Latency** | <3 sec | Including availability checks |
| **Hallucination Rate** | 0% | No invented availability in 10 runs |

---

## Integration Checklist

Before connecting to Orchestrator:

- [ ] System prompt fully in agent node
- [ ] Calendar Check Availability tool connected
- [ ] Check Attendee Availability tool connected
- [ ] Calendar Create Event tool connected
- [ ] Temperature set to 0.2
- [ ] All 6 tests passing (T3, T4, T5, T6, T9, T11)
- [ ] Langfuse traces reviewed
- [ ] No events created without confirmation
- [ ] Unusual times flagged with confirmation
- [ ] Conflicts detected and alternatives offered

---

## Next Agent: Email Agent

Once Scheduler Agent is working, build the **Email Agent**:
- Reads unread emails
- Groups by urgency
- Extracts action items
- Never fabricates content

See `EMAIL_AGENT_PROMPT.md` for complete specification.

---

*CalendarMate Scheduler Agent | Mahesh P. Zade | 09 Sept 2026*
